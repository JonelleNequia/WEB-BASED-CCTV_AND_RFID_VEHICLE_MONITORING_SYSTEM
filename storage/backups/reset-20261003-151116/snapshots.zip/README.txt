Snapshots and frames saved before `system:reset` on 2026-10-03 15:11:16.
